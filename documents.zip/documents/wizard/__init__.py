# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import documents_link_to_record_wizard
from . import documents_request_wizard
