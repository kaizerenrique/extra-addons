from . import test_approval
from . import test_ir_model
from . import test_report_editor
from . import test_ui
from . import test_view_normalization
from . import test_view_editor
from . import test_export
