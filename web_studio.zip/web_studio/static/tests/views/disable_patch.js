/** @odoo-module */

import { unpatchListRendererStudio } from "@web_studio/views/list/list_renderer";

unpatchListRendererStudio();
